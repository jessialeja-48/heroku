class PageController < ApplicationController
  def index
  end
end
